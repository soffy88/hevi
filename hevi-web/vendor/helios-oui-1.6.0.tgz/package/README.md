# @helios/oui

Helios OUI 框架 — 应用骨架 + 标准页面 + 路由目录,基于 [@helios/blocks](../helios-blocks)。

## 安装

```bash
npm install @helios/oui @helios/blocks
```

## 快速开始

```tsx
import { OAppShell, OAppProviders } from '@helios/oui';
import { OLoginPage } from '@helios/oui/pages';
import { authPages, allOUIPages } from '@helios/oui/routes';

import '@helios/blocks/styles.css';
import '@helios/blocks/themes/professional.css';

export default function App() {
  return (
    <OAppProviders theme="professional">
      <OAppShell
        topbarProps={{ title: 'MyApp' }}
        sidebarProps={{
          items: [
            { id: 'dash', label: 'Dashboard', icon: '📊' },
            { id: 'audit', label: '审计', icon: '📜' },
          ],
        }}
      >
        {/* 业务路由 */}
      </OAppShell>
    </OAppProviders>
  );
}
```

## 4 个子模块(按需 import)

| Module | 说明 | Import |
|---|---|---|
| `@helios/oui` | 主入口(全部 re-export)| 默认 |
| `@helios/oui/shell` | OAppShell / OTopBar / OSideBar / OAuthShell | `import { OAppShell } from '@helios/oui/shell'` |
| `@helios/oui/pages` | 11 个标准 Page | `import { OLoginPage } from '@helios/oui/pages'` |
| `@helios/oui/providers` | OAppProviders 一站式 | `import { OAppProviders } from '@helios/oui/providers'` |
| `@helios/oui/routes` | PageMeta[] 路由目录 + 工具 | `import { authPages } from '@helios/oui/routes'` |

## 11 个标准 Page

| Page | 路径默认 | Layout | 需登录 |
|---|---|---|:---:|
| OLoginPage | `/login` | auth | ✗ |
| OSignupPage | `/signup` | auth | ✗ |
| OForgotPasswordPage | `/forgot-password` | auth | ✗ |
| ONotFoundPage | `*` | fullscreen | ✗ |
| OUnauthorizedPage | `/403` | fullscreen | ✗ |
| OErrorBoundaryPage | `/error` | fullscreen | ✗ |
| OMaintenancePage | `/maintenance` | fullscreen | ✗ |
| OSettingsPage | `/settings` | app | ✓ |
| OMembersPage | `/members` | app | ✓ admin+ |
| OAuditLogPage | `/audit` | app | ✓ admin+ |
| OOnboardingPage | `/onboarding` | minimal | ✓ |

## 装配权:不限制

OUI 设计原则是"提供默认 + 允许任意覆盖"。三层装配权:

1. **OAppShell slot 替换** — `<OAppShell topbar={<MyTopBar />} sidebar={false}>` 整体替换或关闭
2. **Page 选择性引入** — 用 `omitPages(allOUIPages, ['signup'])` 删某页;或不用 routes catalog 直接 `import` 单 Page
3. **PageMeta 中性格式** — 你的路由库不重要,5 行 glue 转格式:
   ```tsx
   // Next.js App Router(app/login/page.tsx)
   export { default } from '@helios/oui/pages';  // 实际写 OLoginPage 路径

   // React Router v7
   const routes = allOUIPages.map(p => ({ path: p.path, element: <p.component /> }));

   // TanStack Router
   const tree = allOUIPages.map(p => createRoute({ path: p.path, component: p.component }));
   ```

## 工具

- `findPage(pages, id)` — 按 id 查找
- `omitPages(pages, ids)` — 删除某些 page
- `patchPage(pages, id, patch)` — 修改某 page 字段(如改 title 做 i18n)

## 与 @helios/blocks 的关系

- `@helios/blocks` = OUI 元素库(117 Block + 13 Frame + 17 Provider + 11 Theme)
- `@helios/oui` = OUI 框架(App Shell + Page + 路由目录),build on blocks
- 两包独立发布,版本独立,peer dep 关系

## 版本

0.1.0 (Phase 1) — 11 Page + 4 Shell + 1 Provider + 5 route groups

后续 Phase 2(v0.2 / v1.0):`create-helios-app` CLI starter + 更多 Page(Billing / ApiKey / Webhook)。
