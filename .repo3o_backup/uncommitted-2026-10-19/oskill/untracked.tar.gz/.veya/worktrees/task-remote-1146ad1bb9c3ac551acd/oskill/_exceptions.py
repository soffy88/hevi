class OskillError(Exception):
    pass
